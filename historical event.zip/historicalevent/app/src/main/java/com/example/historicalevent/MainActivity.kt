package com.example.historicalevent

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    enum class HistoricalEvent(val year: Int, val description: String) {
        EVENT_1(1776, " Decleration of Indpendence in the United Stateds"),
        EVENT_2(1969, " First moon landing by Apollo 11"),
        EVENT_3(1989, " End of World War II with the surender of Japan"),
        EVENT_4(1492, " Fall of the Berlin Wall"),
        EVENT_5(2001, " Christopher Columbus discovers the Americans"),
        EVENT_6(2001, " September 11 terrorist attacks in the United States"),
        EVENT_7(1912, " French Revolution begins"),
        EVENT8(1963, " Sinking of the Titanic"),
        EVENT_9(1776, " Assassination of John F. Kennedy"),
        EVENT_10(1776, " Wall Street Crash and the beginning bof the Great Drepression"),

    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtBirthYear = findViewById<EditText>(R.id.edtBirthYear)
        val btnResult = findViewById<Button>(R.id.DisplayResultBtn)
        val btnclrResult = findViewById<Button>(R.id.ClearResultBtn)
        val edtResult = findViewById<TextView>(R.id.result1)

        btnResult?.setOnClickListener {

            val birthYear = edtBirthYear.text.toString().toInt()

            if (birthYear != null && birthYear in 1500 .. 2024) {

                val eventYears = HistoricalEvent.values().map {it.year }

                val events = when (birthYear)
                {
                    in eventYears -> {
                        val event = HistoricalEvent.values().find { it.year == birthYear }
                        listOf("in $birthYear: ${event?.description ?: "event"}")
                    }
                    in eventYears.map { it - 1} -> {
                        val event = HistoricalEvent.values().find { it.year == birthYear - 1 }
                        listOf("Your birth year is one year before the historical event of" + "${event?.description ?: "event"}")

                    }
                    in eventYears.map { it + 1} -> {
                        val event = HistoricalEvent.values().find { it.year == birthYear - 1 }
                        listOf("Your birth year is one year before the historical event of" + "${event?.description ?: "event"}")


                    }

                    else -> listOf("No historical events found for $birthYear.")

                    }
                edtResult.text = events.joinToString( "\n")

                } else {
                    edtResult.text = "Please enter a birth year that is not 0 and meets the required range (1500-2024)"
            }
            btnclrResult?.setOnClickListener() {
                edtBirthYear.text.clear()
                edtResult.text = ""
            }
        }
    }
}